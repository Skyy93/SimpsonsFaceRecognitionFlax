import os
import csv
import random


simpsons_list = list()

for r, dirs, files in os.walk("."):
    for file in files:
      if file[-4:] == '.jpg':
        if 'homer' in file:
          simpsons_list.append((str('D:\simpsons_faces\\' + file) , 0))
        elif 'marge' in file:
          simpsons_list.append((str('D:\simpsons_faces\\' + file) , 1))
        elif 'bart' in file:
          simpsons_list.append((str('D:\simpsons_faces\\' + file) , 2))
        elif 'lisa' in file:
          simpsons_list.append((str('D:\simpsons_faces\\' + file) , 3))



random.shuffle(simpsons_list)

train = simpsons_list[:int(len(simpsons_list)/4*3)]
test = simpsons_list[int(len(simpsons_list)/4*3):]

with open('labels_train.csv', 'wb') as csvfile:
  writer = csv.writer(csvfile)
  for i in train:
    writer.writerow(i)

with open('labels_test.csv', 'wb') as csvfile:
  writer = csv.writer(csvfile)
  for i in test:
    writer.writerow(i)